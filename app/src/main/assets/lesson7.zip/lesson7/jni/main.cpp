#include <dlfcn.h>
#include <jni.h>
#include <string>
#include <stdlib.h>
#include <vector>
#include <android/log.h>
#include "Substrate.h"
#include <sstream>
#include "minecraftpe/client/MinecraftClient.h"
#include "minecraftpe/client/gui/Gui.h"
#include "minecraftpe/entity/player/Player.h"

void (*MinecraftClient_onPlayerLoaded_real)(MinecraftClient*, Player*);
void MinecraftClient_onPlayerLoaded_hook(MinecraftClient*mc, Player*p)
{
	mc->getGui()->displayClientMessage("Welcome!");
	MinecraftClient_onPlayerLoaded_real(mc,p);
}


JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved){
MSHookFunction((void*) &MinecraftClient::onPlayerLoaded, (void*) &MinecraftClient_onPlayerLoaded_hook, (void**) &MinecraftClient_onPlayerLoaded_real);

return JNI_VERSION_1_2;
}