#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <stdlib.h>
#include <substrate.h>


#pragma once
#include <string>
#include <vector>
class Skin;
class SkinPack {
public:
        enum class SkinPackType {
                DEFAULT, PACK
        };
 
        std::string id;// 4
        std::string name;// 8
        int filler1;// 12
        bool purchased;// 16
        std::vector<Skin*> skins; // 28
        SkinPack::SkinPackType type; // 32
 
        SkinPack(SkinPack::SkinPackType, std::string const&, std::string, std::initializer_list<Skin> const&);
};
class Skin {
public:
        enum class ModelType {
                STEVE, ALEX
        };
        enum class SkinType {
                DEFAULT, FREE, PAID
        };
 
        int filler; // 4; always 0
        std::string id; // 8
        std::string name; // 12
        std::string path; // 16
        Skin::ModelType model; // 20
        Skin::SkinType type; // 24
 
        Skin(std::string const&, std::string const&, std::string const&, Skin::ModelType, Skin::SkinType);
        void setSkinPack(SkinPack*);
        bool premiumLocked() const;
};
class SkinPackRepository {
public:
        char filler[0x10];
        std::vector<SkinPack*> skinPacks;
};
 
class GameStore;
class Textures;
 
static void (*skinRepoOrg)(SkinPackRepository*, GameStore&, Textures&, std::string const&);
void skinRepoHook(SkinPackRepository* repo, GameStore& store, Textures& tex, std::string const& text) {
        skinRepoOrg(repo, store, tex, text);
 
        Skin test ("Alex", "Mage of Doom", "mob/skins/MageofDoom.png", Skin::ModelType::STEVE, Skin::SkinType::FREE);
		Skin testl ("Alex", "The Mask Man", "mob/skins/themaskman.png", Skin::ModelType::STEVE, Skin::SkinType::FREE);
        SkinPack* pack = new SkinPack(SkinPack::SkinPackType::PACK, "Тест", "Тестовый скинпак!", {test, testl});
        repo->skinPacks.push_back(pack);
        pack->purchased = true;
}
 
JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
        void* sym = dlsym(RTLD_DEFAULT, "_ZN14SkinRepositoryC2ER9GameStoreR8TexturesRKSs");
MSHookFunction(sym, (void*) &skinRepoHook, (void**) &skinRepoOrg);
 
        return JNI_VERSION_1_2;
 
}
