#include <jni.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <vector>
#include <string>

#include "Substrate.h"

#include "minecraftpe/motive/Motive.h"

static Motive* Furniture;
void Motive::initCustomMotives() {
	Furniture  = new Motive("PeClubs", 65, 32, 128, 160, true);
}

void initMod() {
	Motive::initCustomMotives();
}

static std::vector<const Motive*> (*_Motive$getAllMotivesAsList)();
static std::vector<const Motive*> Motive$getAllMotivesAsList() {
	
	std::vector<const Motive*> retval = _Motive$getAllMotivesAsList();
	retval.push_back(Furniture);
	return retval;
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
  void* handle = dlopen("libminecraftpe.so", RTLD_LAZY);	
 initMod();
  MSHookFunction((void*) &Motive::getAllMotivesAsList, (void*) &Motive$getAllMotivesAsList, (void**) &_Motive$getAllMotivesAsList);

 // MSHookFunction((void*) &Item::initItems, (void*) &Item$initItems, (void**) &_Item$initItems);

return JNI_VERSION_1_2;
}
