#pragma once

#include <vector>
#include <string>

#include "ItemInstance.h"

class Recipe;
class Tile;

class Recipes {
public:
	std::vector<Recipe*> recipes;
	class Type {
	public:
		Item* item;
		Tile* tile;
		ItemInstance itemInstance;
		char c;

		Type(char c, Item* item) : c(c), item(item) {}
		Type(char c, Tile* tile) : c(c), tile(tile) {}
		Type(char c, Item* item, int damage) : c(c), item(NULL), tile(NULL), itemInstance(item, 1, damage) {}
		Type(char c, Tile* tile, int damage) : c(c), item(NULL), tile(NULL), itemInstance(tile, 1, damage) {}
	};

	static Recipes* getInstance();
	void addShapedRecipe(ItemInstance const&, std::string const&, std::vector<Recipes::Type> const&);
	void addShapedRecipe(ItemInstance const&, std::string const&, std::string const&, std::vector<Recipes::Type> const&);
	void addShapedRecipe(ItemInstance const&, std::string const&, std::string const&, std::string const&, std::vector<Recipes::Type> const&);
	void addShapedRecipe(ItemInstance const&, std::vector<std::string> const&, std::vector<Recipes::Type> const&);
	
  /* ================================================================================== */
	/* This is the important function: the first argument is a vector of crafting results */
	void addShapedRecipe(std::vector<ItemInstance> const&, std::vector<std::string> const&, std::vector<Recipes::Type> const&);
  /* ================================================================================== */
  
	void addSingleIngredientRecipeItem(ItemInstance const&, ItemInstance const&);
};