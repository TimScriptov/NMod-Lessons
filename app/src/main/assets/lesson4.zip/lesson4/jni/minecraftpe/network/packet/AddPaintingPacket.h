#pragma once

#include "../Packet.h"

class AddPaintingPacket : public Packet
{
public:
};
