#pragma once

#include "TamableAnimal.h"

class Wolf : public TamableAnimal {
public:
	Wolf(TileSource&);
	~Wolf();
	virtual const int getCollarColor();
	virtual void setCollarColor(int);
	virtual const bool isAngry();
	virtual float getHeadRollAngle(float);
	virtual float getBodyRollAngle(float, float);
	virtual float getBaseSpeed();
	virtual const int getEntityTypeId();
	virtual bool doHurtTarget(Entity*);
	virtual const bool shouldDespawn();
	virtual std::string getHurtSound(); // protected?
	virtual std::string getDeathSound(); // protected?
	virtual const bool isFood(ItemInstance const*);
	virtual bool canInteractWith(Player*);
	virtual float getWetShade(float);
	virtual const bool isWet();
	virtual void setWet(bool);
	virtual const char* getAmbientSound();
	virtual std::string& getTexture();
	virtual std::string getInteractText(Player*);
	virtual const bool isInterested();
	virtual void setAngry(bool);
	virtual void setInterested(bool);
	virtual Animal* getBreedOffspring(Animal*);
};
