#pragma once

#include "Animal.h"

class Pig : public Animal
{
public:

};