#pragma once

enum GeneratorType
{

};
