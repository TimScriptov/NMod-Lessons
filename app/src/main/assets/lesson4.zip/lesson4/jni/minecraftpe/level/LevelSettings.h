#pragma once

class LevelSettings
{
public:
	unsigned int randomSeed;	// 0
	int theGameType;			// 4
	// .
	// .
	// .
	// ?
};
