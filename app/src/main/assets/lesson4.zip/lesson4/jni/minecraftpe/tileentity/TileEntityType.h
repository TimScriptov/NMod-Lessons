#pragma once

enum TileEntityType
{
	FURNACE = 1,
	CHEST,
	NETHERREACTOR,
	SIGN,
	MOBSPAWNER
};