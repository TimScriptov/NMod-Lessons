#include <jni.h>
#include <dlfcn.h>
#include <stdlib.h>
#include <vector>
#include <string>

#include "Substrate.h"

#include "minecraftpe/item/Recipes.h"
#include "minecraftpe/item/Item.h"
#include "minecraftpe/tile/Tile.h"


void (*ToolRecipes_real)(Recipes*);
void ToolRecipes_hook(Recipes* recipes) {
 
  
    std::vector<Recipes::Type> ingredients;
	std::vector<std::string> shape;
	std::vector<ItemInstance> results;
	
	ingredients.push_back(Recipes::Type('U', Item::bucket, 10))
	ingredients.push_back(Recipes::Type('/', Item::stick));
	
	results.push_back(ItemInstance(Tile::torch, 64));
	results.push_back(ItemInstance(Item::bucket));
	
	shape.push_back("#U#");
	shape.push_back("#/#");
  
  recipes->addShapedRecipe(results, shape, ingredients);
  
  
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
  void* handle = dlopen("libminecraftpe.so", RTLD_LAZY);	
  MSHookFunction((void*) dlsym(handle, "_ZN11ToolRecipes10addRecipesEP7Recipes"), (void*) &ToolRecipes_hook, (void**) &ToolRecipes_real);

	return JNI_VERSION_1_2;
}
