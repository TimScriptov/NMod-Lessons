#pragma once

class FullTile {
public:
	static const FullTile AIR;

public:
	unsigned char _id;
	unsigned char _damage;
};
