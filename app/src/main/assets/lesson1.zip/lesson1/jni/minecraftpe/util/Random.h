#pragma once

class Random {
	Random();
	int genrand_int32();
};
