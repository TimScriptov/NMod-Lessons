#pragma once

class LightLayer {
public:
	static const LightLayer Block;
	static const LightLayer Sky;

public:
	char filler1[8];
};
