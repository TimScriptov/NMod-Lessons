#pragma once

class TileID {
public:
	static const TileID AIR;

public:
	unsigned char _id;	// 0
};
