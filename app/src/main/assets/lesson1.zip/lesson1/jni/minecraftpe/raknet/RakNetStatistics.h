#pragma once

#include "RakNetTime.h"

namespace RakNet {
struct RakNetStatistics {

};
}
