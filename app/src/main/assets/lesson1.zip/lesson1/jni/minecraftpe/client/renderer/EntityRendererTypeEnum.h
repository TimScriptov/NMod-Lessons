#pragma once

enum EntityRendererId { // TODO
	//RENDERER_
};
