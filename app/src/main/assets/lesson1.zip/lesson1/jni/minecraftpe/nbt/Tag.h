#pragma once

class Tag {
public:
	virtual ~Tag();
};
