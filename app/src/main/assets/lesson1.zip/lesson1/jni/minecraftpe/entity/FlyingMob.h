#pragma once

#include "minecraftpe/entity/Mob.h"

class FlyingMob : public Mob {
public:
	FlyingMob(TileSource &);
};
