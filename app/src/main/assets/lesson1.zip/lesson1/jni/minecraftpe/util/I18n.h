#pragma once

class I18n {
public:
	static std::string get(const std::string &);
	static std::string get(const std::string &, std::string &);
};
