#pragma once

class TileSource;

class PathFinder {
public:
	PathFinder(TileSource *, bool, bool, bool, bool);
};
