#pragma once

#include "minecraftpe/entity/AgableMob.h"

class Animal : public AgableMob {
public:
	Animal(TileSource &);
};
