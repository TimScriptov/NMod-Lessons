#pragma once

namespace RakNet {
class RakPeer {
public:
	RakPeer();
	unsigned short 	NumberOfConnections() const;
};
}
