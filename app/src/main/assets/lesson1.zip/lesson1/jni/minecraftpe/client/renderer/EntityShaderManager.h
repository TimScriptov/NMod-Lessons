#pragma once

class EntityShaderManager {
public:
	EntityShaderManager();
};
