#pragma once

class MemoryTracker {
public:
	//void** vtable;	// 0

public:
	MemoryTracker(const std::string &, MemoryTracker*);
};
