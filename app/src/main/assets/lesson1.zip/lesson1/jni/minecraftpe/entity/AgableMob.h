#pragma once

#include "minecraftpe/entity/PathfinderMob.h"

class AgableMob : public PathfinderMob {
public:
	AgableMob(TileSource &);
};
