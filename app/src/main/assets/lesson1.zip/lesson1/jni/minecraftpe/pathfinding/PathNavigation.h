#pragma once

class Mob;
class Level;

class PathNavigation {
public:
	PathNavigation(Mob *, Level *, float);
};
