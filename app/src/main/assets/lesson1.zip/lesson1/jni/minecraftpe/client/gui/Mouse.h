#pragma once

class Mouse {
	static float getX();
	static float getY();
	static bool isButtonDown(int);
};
