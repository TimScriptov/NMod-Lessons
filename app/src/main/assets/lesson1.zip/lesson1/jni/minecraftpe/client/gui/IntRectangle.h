#pragma once

class IntRectangle {
public:
	int x;		// 0
	int y;		// 4
	int width;	// 8
	int height;	// 12
};
