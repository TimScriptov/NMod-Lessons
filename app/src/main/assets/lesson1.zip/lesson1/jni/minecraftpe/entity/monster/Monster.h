#pragma once

#include "minecraftpe/entity/PathfinderMob.h"

class Monster : public PathfinderMob {
public:
	Monster(TileSource &);
};
