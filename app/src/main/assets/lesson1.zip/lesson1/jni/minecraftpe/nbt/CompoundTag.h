#pragma once

#include "minecraftpe/nbt/Tag.h"

class CompoundTag : public Tag {
public:

};
