#pragma once

#include "minecraftpe/AppPlatformListener.h"

class RenderMaterialGroup : public AppPlatformListener {
public:
	RenderMaterialGroup();
	~RenderMaterialGroup();
};
