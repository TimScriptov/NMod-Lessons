#pragma once

//class Options;
//class AppPlatform;

class Textures {
public:
	// Size : 88

public:
	//Textures(Options *, AppPlatform *);
	void bindTexture(const std::string &);
};
