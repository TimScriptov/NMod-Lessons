#pragma once

#include "minecraftpe/entity/Mob.h"

class PathfinderMob : public Mob {
public:
	PathfinderMob(TileSource &);
};
