#pragma once

class LevelSettings{

};
