#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <time.h>

#include "Substrate.h"
#include "shared.h"
#include "mcpelauncher.h"
#include "minecraftpe/entity/player/Player.h"
#include "minecraftpe/client/MinecraftClient.h"
#include "minecraftpe/client/gui/StartMenuScreen.h"
#include "minecraftpe/client/gui/GuiElement.h"
#include "minecraftpe/command/ServerCommandParser.h"
#include "minecraftpe/util/Token.h"
#include "minecraftpe/inventory/Container.h"

static char** gSplashes;

static void (*Touch_StartMenuScreen_chooseRandomSplash_real)(Touch::StartMenuScreen*);
static void Touch_StartMenuScreen_chooseRandomSplash_hook(Touch::StartMenuScreen* screen)
{
	gSplashes[0] = "Minecraft PE Addons News";
	screen->currentSplash = 0;
}

static std::string (*getGameVersionString_real)();

static std::string getGameVersionString_hook() {
	return "C++";
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	void* handle = dlopen("libminecraftpe.so", RTLD_LAZY);

	gSplashes = (char**) dlsym(handle, "gSplashes");

	void* getGameVersionString = dlsym(RTLD_DEFAULT, "_ZN6Common20getGameVersionStringEv");
	MSHookFunction(getGameVersionString, (void*)&getGameVersionString_hook, (void**)&getGameVersionString_real);

	MSHookFunction((void*) &Touch::StartMenuScreen::chooseRandomSplash, (void*) &Touch_StartMenuScreen_chooseRandomSplash_hook, (void**) &Touch_StartMenuScreen_chooseRandomSplash_real);

	return JNI_VERSION_1_2;
}
