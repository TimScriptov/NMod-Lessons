#pragma once

#include "TamableAnimal.h"

class Wolf : public TamableAnimal
{
public:

};