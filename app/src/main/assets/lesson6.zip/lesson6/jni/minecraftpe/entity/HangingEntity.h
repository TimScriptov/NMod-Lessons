#pragma once

#include "Entity.h"

class HangingEntity : public Entity
{
public:

};
