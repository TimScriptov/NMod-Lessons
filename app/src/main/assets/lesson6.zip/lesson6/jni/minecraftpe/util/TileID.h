#pragma once

class TileID
{
public:
	static TileID AIR;

public:
	unsigned char id;	// 0
};
