#pragma once

class ChunkSource
{
public:
	ChunkSource(ChunkSource *, bool);
};