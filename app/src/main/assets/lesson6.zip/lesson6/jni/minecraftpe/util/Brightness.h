#pragma once

class Brightness
{
public:
	static Brightness MAX;
	static Brightness MIN;

public:
	unsigned char value;
};
