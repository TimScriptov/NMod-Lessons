#pragma once

class Packet;

class MinecraftPackets
{
public:
	static Packet *createPacket(int);
};