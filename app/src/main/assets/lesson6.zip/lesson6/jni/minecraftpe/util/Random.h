#pragma once

class Random
{
public:
	Random();
	int genrand_int32();
};