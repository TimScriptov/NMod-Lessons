#pragma once

class LevelChunk
{
public:
	LevelChunk(Level &, const ChunkPos &, bool);
};