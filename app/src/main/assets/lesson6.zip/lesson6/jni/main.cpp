#include <dlfcn.h>
#include <jni.h>
#include <string>
#include <stdlib.h>
#include <vector>
#include <android/log.h>
#include "Substrate.h"
#include <sstream>
#include "minecraftpe/entity/Mob.h"

void (*Mob_die_real)(EntityDamageSource&);
void Mob_die_hook(EntityDamageSource& eds)
{
	Mob_die_hook(eds);
}


JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved){
MSHookFunction((void*) &Mob::die, (void*) &Mob_die_hook, (void**) &Mob_die_real);

return JNI_VERSION_1_2;
}