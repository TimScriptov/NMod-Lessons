#pragma once

#include <string>
#include <memory>
#include <map>

class LevelSettings;
class Textures;
class Options;
class PacketSender;
class Level;
class Vibration;
class Player;
class ItemInstance;
class TilePos;
class Vec3;
class Entity;
class Abilities;
class Gui;
class TilePos {
public:
	int x;
	int y;
	int z;
	
	TilePos(float, float, float);
};

class Common {
public:
	static std::string getGameVersionString();
	static std::string getGameVersionStringNet();
};

class Entity {
public:
	char filler[24];
	float x;
	float y;
	float z;
	char filler2[48];
	float rotX;
	float rotY;
};

class Mob : public Entity {};

class Player : public Mob {
public:
	virtual void displayChatMessage(const std::string &, const std::string &);
	virtual void displayClientMessage(const std::string &);
	//virtual void displayLocalizableMessage(const std::string &, const std::vector<std::string> &);
	std::string playerName;
};

class LocalPlayer : public Player {
public:
	void sendPosition();
};

class Color {
public:
	static Color const WHITE;
};

class GuiElement {
	
};



class Font {
public:
	Font(Options*, std::string const&, Textures*);
    void draw(const std::string &, float, float, const Color &);
	void draw(const std::string &, float, float, const Color &, bool);
	//void drawCached(const std::string &, float, float, const Color &, bool, MaterialPtr *);
	void drawShadow(const std::string &, float, float, const Color &);
	void drawTransformed(std::string const&, float, float, Color const&, float, float, bool, float);
	int getLineLength(std::string const&) const;
};

class MinecraftClient
{
public:
					// 316
	LocalPlayer *player;					// 332
	Gui *gui;								// 336			// 344
				// 364

public:
	MinecraftClient(int, char **);
	virtual ~MinecraftClient();
	virtual void onLowMemory();
	virtual void onAppSuspended();
	virtual void onAppResumed();
	virtual void onAppFocusLost();
	virtual void onAppFocusGained();
	virtual void audioEngineOn();
	virtual void audioEngineOff();
	virtual void muteAudio();
	virtual void unMuteAudio();
	virtual void useTouchscreen();
	virtual void setTextboxText(std::string const&);
	virtual void setSize(int, int, float);
	virtual void handleBack(bool);
	virtual void handleBack();
	virtual void init();
	virtual void teardown();
	virtual void startFrame();
	virtual void endFrame();
	virtual void tick(int, int);
	virtual void leaveGame(bool);
	virtual void play(const std::string &, float, float, float, float, float);
	virtual void playUI(const std::string &, float, float);
	virtual void isServerVisible();
	virtual void sendLocalMessage(const std::string &, const std::string &);
	virtual void getPlayer();
	virtual void onInternetUpdate();
	virtual void createLocalClientNetworkHandler();
	virtual void getSoundPlayer();
	virtual void getVibration();
	virtual void getLocalPlayer();
	virtual void vibrate(int);
	void _createDefaultInput();
	void _reloadFancy(bool);
	void _reloadLanguages();
	void freeResources(bool);
	float getDpadScale();
	Gui *getGui();
	void *getOptions();
	void grabMouse();
	void handleBackNoReturn();
	void handleMouseClick(int);
	void handleMouseDown(int, bool);
	void initFoliageAndTileTextureTessellator();
	void initGLStates();
	void initSnoopClient();
	void isKindleFire(int);
	void joinMultiplayer(char const *, int, bool);
	void locateMultiplayer();
	void onPlayerLoaded(Player &);
	void onUpdatedClient(int, int, int, int);
	void rebuildLevel();
	void releaseMouse();
	void resetInput();
	void restartServer();
	void sendHardwareSnoopEvent();
	void setDpadScale(float);

	bool supportNonTouchScreen();
	void tickInput();
	void transformResolution(int *, int *);
	void updateScheduledScreen();
	void updateStats();
	bool useController();
};


class GameMode
{
public:
	//void **vtable;				// 0
	//char filler1[8];				// 4
	PacketSender *packetSender;		// 12
	Level *level;					// 16
	//char filler1[12];				// 20

public:
	GameMode(PacketSender &, Level &, Vibration &);
	virtual ~GameMode();
	virtual void startDestroyBlock(Player *, int, int, int, signed char);
	virtual void destroyBlock(Player *, int, int, int, signed char);
	virtual void continueDestroyBlock(Player*, int, int, int, signed char) = 0;
	virtual void stopDestroyBlock(Player *);
	virtual void tick();
	virtual void getPickRange();
	virtual void initPlayer(Player*);
	virtual void canHurtPlayer();
	virtual void interact(Player *, Entity *);
	virtual void attack(Player *, Entity *);
	virtual void handleInventoryMouseClick(int, int, int, Player *);
	virtual void handleCloseInventory(int, Player *);
	virtual void isCreativeType();
	virtual void isSurvivalType();
	virtual void initAbilities(Abilities &);
	virtual void releaseUsingItem(Player *);
};


class Button {
public:
	char filler[68];
	int x;
	int y;
	int width;
	int height;
	Button(int, std::string const&, bool);
	void render(MinecraftClient*, int, int);
	bool isInside(int, int);
	Button(int, int, int, int, int, const std::string &, bool);
	Button(int, int, int, const std::string &);
	Button(int, const std::string &, bool);
};

class Gui {
public:
	void render(float, bool, int, int);
	void displayClientMessage(const std::string &);
	void showPopupNotice(const std::string &);
	void showTipMessage(const std::string &);
};


namespace Touch
{

// Size : 176
class TButton : public Button
{
public:
//	NinePatchLayer *ninepathLayer1;		// 168
	//NinePatchLayer *ninepathLayer2;		// 172

public:
	TButton(int, int, int, int, int, const std::string &, MinecraftClient *, bool, int);
	TButton(int, int, int, const std::string &, MinecraftClient *, int);
	TButton(int, const std::string &, MinecraftClient *, bool, int);
	virtual ~TButton();
	virtual void renderBg(MinecraftClient *, int, int);
	void init(MinecraftClient *);
	//void init(MinecraftClient *, const std::string &, const IntRectangle &, const IntRectangle &, int, int, int, int);
};

};


class Biome {
public:
	enum BiomeType {
		Beach,
		Desert,
		ExtremeHills,
		Flat,
		Forest,
		Hell,
		Ice,
		Jungle,
		Mesa,
		MushroomIsland,
		Ocean,
		Plain,
		River,
		Savanna,
		StoneBeach,
		Swamp,
		Taiga,
		TheEnd
	};
	
	Biome::BiomeType getBiomeType();
};

std::map<Biome::BiomeType, std::string> biomeTypeNames = {
	{Biome::BiomeType::Beach, "Beach"},
	{Biome::BiomeType::Desert, "Desert"},
	{Biome::BiomeType::ExtremeHills, "Extreme Hills"},
	{Biome::BiomeType::Flat, "Flat"},
	{Biome::BiomeType::Forest, "Forest"},
	{Biome::BiomeType::Hell, "Hell"},
	{Biome::BiomeType::Ice, "Ice"},
	{Biome::BiomeType::Jungle, "Jungle"},
	{Biome::BiomeType::Mesa, "Mesa"},
	{Biome::BiomeType::MushroomIsland, "Mushroom Island"},
	{Biome::BiomeType::Ocean, "Ocean"},
	{Biome::BiomeType::Plain, "Plains"},
	{Biome::BiomeType::River, "River"},
	{Biome::BiomeType::Savanna, "Savanna"},
	{Biome::BiomeType::StoneBeach, "Stone Beach"},
	{Biome::BiomeType::Swamp, "Swamp"},
	{Biome::BiomeType::Taiga, "Taiga"},
	{Biome::BiomeType::TheEnd, "The End"}
};

class LightLayer {
public:
	static const LightLayer Sky;
	static const LightLayer Block;
};

class TileSource {
public:
	int getBrightness(LightLayer const&, TilePos const&);
	Biome* getBiome(TilePos const&);
};

class Level {
public:
	void onSourceCreated(TileSource*);
	LocalPlayer* getLocalPlayer();
	int getDifficulty() const;
	//Player* getPlayer();
	long getTime() const;
	void setTime(long);
	void setNightMode(bool);
};

void mouseDown(int, int, int);

class AppPlatform {
public:
	static int getScreenWidth();
	static float getPixelsPerMillimeter();
};

class Item {
public:
	static Item* items[512];
};

class CreativeInventoryScreen {
public:
	static void populateItem(Item*, int, int);
};
