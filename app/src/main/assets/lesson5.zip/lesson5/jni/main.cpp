#include <dlfcn.h>
#include <jni.h>
#include <string>
#include <stdlib.h>
#include <vector>
#include <android/log.h>
#include "Substrate.h"
#include <sstream>
#include "minecraftpe/entity/player/Player.h"
#include "minecraftpe/client/MinecraftClient.h"

void (*Player_onPlayerLoaded_real)(MinecraftClient*, Player*);
void Player_onPlayerLoaded_hook(MinecraftClient*mc, Player*p)
{
	Player_onPlayerLoaded_real(mc,p);
}


JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved){
MSHookFunction((void*) &MinecraftClient::onPlayerLoaded, (void*) &Player_onPlayerLoaded_hook, (void**) &Player_onPlayerLoaded_real);

return JNI_VERSION_1_2;
}