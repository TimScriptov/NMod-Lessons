#pragma once

enum ActionEnum
{
	none,
	eat,
	drink,
	block,
	bow
};
