#pragma once

// Size : 16
class SynchedEntityData
{
public:
	SynchedEntityData();
	SynchedEntityData(SynchedEntityData &&);
	~SynchedEntityData();
};
