#pragma once

class LevelSettings
{

};