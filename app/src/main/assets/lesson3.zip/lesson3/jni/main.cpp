#include <jni.h>
#include <dlfcn.h>
#include <android/log.h>
#include <stdlib.h>
#include <Substrate.h>

#include <mcpe/Item.h>
#include <mcpe/ItemInstance.h>

class NewItem: public Item {
public:
	static int ID;
	static NewItem* item;
	NewItem(int);
};

int NewItem::ID = 500;
NewItem* NewItem::item = NULL;

NewItem::NewItem(int id): Item(id - 256) {
	setNameID("NewItem");
	setIcon("blaze_rod", 0);
	setMaxStackSize(64);
	handEquipped();
	setCategory(3);
}

static void (*ItemInitItems_real)();
static void ItemInitItems_hook() {
	ItemInitItems_real();
	NewItem::item = new NewItem(NewItem::ID);
}

JNIEXPORT jint JNI_OnLoad(JavaVM* vm, void* reserved) {
	MSHookFunction((void*) &Item::initItems, (void*) &ItemInitItems_hook, (void**) &ItemInitItems_real);
	return JNI_VERSION_1_2;
}
